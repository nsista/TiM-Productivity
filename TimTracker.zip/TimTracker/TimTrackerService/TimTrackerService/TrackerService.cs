﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace TimTrackerService
{
    public class TrackerService : ITrackerService
    {
        public static string appName, prevvalue,CategoryName;        
        public static DateTime applfocustime;
        public static string appltitle;
        public static string fileName;
        public ActivityLogger logger;
        public Guid ProjectID;        
        public static bool isProjectIDExists = false;
        public List<ProjectInfo> GetProjectInfo()
        {
            ProductivityTrackerEntities entity = new ProductivityTrackerEntities();
            var res = GetChartData("year", DateTime.Now, DateTime.Now);
            return entity.ProjectInfoes.ToList();
        }

        public void SaveActivity(ActivityLogger logger)
        {
            using (var context = new ProductivityTrackerEntities())
            {
                context.ActivityLoggers.Add(logger);
                context.SaveChanges();
            }     
        }

        public void SaveProjectInfo(ProjectInfo prjInfo)
        {
            ProductivityTrackerEntities entity = new ProductivityTrackerEntities();
            entity.ProjectInfoes.Add(prjInfo);
            entity.SaveChanges();
        }
        public void ActivityLogger()
        {
            try
            {
                bool isNewAppl = false;
                    IntPtr hwnd = APIFuncs.getforegroundWindow();
                    Int32 pid = APIFuncs.GetWindowProcessID(hwnd);
                    Process p = Process.GetProcessById(pid);
                    appName = p.ProcessName;
                    fileName = p.Modules[0].FileName;
                    appltitle = APIFuncs.ActiveApplTitle().Trim().Replace("\0", "");               
                    if (!isProjectIDExists)
                        isProjectIDExists = this.isKeywordExists(appltitle,appName);
                    if (isProjectIDExists)
                    {

                        if (logger == null)
                        {
                            logger = new ActivityLogger();
                            logger.ProcessName = appName;
                            logger.ActivityName = appltitle;
                            logger.ActivityStartTime = DateTime.Now;
                            logger.ProjectID = ProjectID;
                            logger.CategoryName = CategoryName;
                            
                            isNewAppl = true;
                            prevvalue = appltitle + "$$$!!!" + appName;
                        }

                        if (prevvalue != (appltitle + "$$$!!!" + appName))
                        {                            
                            if (prevvalue != null && logger != null)
                            {
                                logger.TimeSpent = DateTime.Now.Subtract(applfocustime);                                
                                SaveActivity(logger);
                                if (isKeywordExists(appltitle,appName))
                                {
                                    logger.ProcessName = appName;
                                    logger.ActivityName = appltitle.Split('-')[0].TrimEnd();
                                    logger.ActivityStartTime = DateTime.Now;
                                    logger.TimeSpent = new TimeSpan(0);
                                    logger.ProjectID = ProjectID;
                                    logger.CategoryName = CategoryName;
                                    isProjectIDExists = true;
                                }
                                else
                                {
                                    logger = null;
                                    isProjectIDExists = false;
                                }
                            }

                            prevvalue = appltitle + "$$$!!!" + appName;
                            applfocustime = DateTime.Now;
                        }
                        else
                        {

                        }
                        if (isNewAppl)
                            applfocustime = DateTime.Now;
                    }
            }
            catch (Exception ex)
            {
               // MessageBox.Show(ex.Message + ":" + ex.StackTrace);
            }
        
        }
        public object GetChartData(string period,DateTime? FromDate,DateTime? Todate )
        {
            ProductivityTrackerEntities entity = new ProductivityTrackerEntities();
           return entity.GetChartData(period, FromDate, Todate);
        }
        public TimActivities GetActivities(string userID)
        {
            ProductivityTrackerEntities entity = new ProductivityTrackerEntities();            
            TimActivities activities = new TimActivities();
            activities.pInfo = entity.ProjectInfoes.Select(p => p).ToList();
            activities.categories = entity.Categories.Select(p => p).ToList();
            activities.activities = entity.ActivityLoggers.Select(p => p).ToList();
            return activities;
        }
        public void GetChartData(string whereClause)
        {
            ProductivityTrackerEntities entity = new ProductivityTrackerEntities();
            Filter filter = new Filter { PropertyName = "ActivityStartTime", Operator = Operator.Equals, Value =Convert.ToDateTime(whereClause) };
            List<Filter> filters = new List<Filter>();
            filters.Add(filter);
           // ExpressionBuilder.GetExpression<ActivityLogger><Filter,bool>();
            var deleg = ExpressionBuilder.GetExpression<ActivityLogger>(filters);
            //System.Linq.Expressions.Expression<Func<Contact, bool>> deleg = ExpressionBuilder.GetExpression<ActivityLogger>(filters);
            var val = entity.ActivityLoggers.Where(deleg);    
            foreach(var v in val)
            {

            }
        }
        private bool isKeywordExists(string app,string appName)
        {
            ProductivityTrackerEntities entity = new ProductivityTrackerEntities();
            var value = entity.ProjectInfoes.Select(p => p);
            bool isExists = false;
            foreach (ProjectInfo pinfo in value)
            {
                if (app.ToUpper().Contains(pinfo.ProjectName.ToUpper()))
                {
                    ProjectID = pinfo.ProjectID;
                    isExists = true;
                    break;
                }
            }
            if(isExists)
            {
                isExists =false;
                var cat = entity.Categories;
                foreach(Category c in cat)
                {
                    if (c.CategoryTypes!=null && c.CategoryTypes.ToUpper().Contains(appName.ToUpper()))
                    {
                        isExists = true;
                        CategoryName = c.CategoryName;
                        break;
                    }
                }
            }
            return isExists;
        }
    }
}
