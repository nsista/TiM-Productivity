﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace ModernUISample
{
    public partial class DrillDown : MetroFramework.Forms.MetroForm
    {
        public DrillDown()
        {
            InitializeComponent();
        }

        private void Chart1_Click(object sender, System.EventArgs e)
        {

        }

        private void chart1_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            // Call Hit Test Method
            HitTestResult result = Chart1.HitTest(e.X, e.Y);

            if (result.ChartElementType != ChartElementType.DataPoint)
                return;

            // Remove data points
            Chart1.Series[0].Points.Clear();

            // If Pie chart is selected
            if (Chart1.Series[0].ChartType == SeriesChartType.Pie)
            {
                // Set Chart Type
                Chart1.Series[0].ChartType = SeriesChartType.Column;

                // Add data points
                Chart1.Series[0].Points.Add(5);
                Chart1.Series[0].Points.Add(6);
                Chart1.Series[0].Points.Add(7);
                Chart1.Series[0].Points.Add(2);

                // Set Axis labels
                Chart1.Series[0].Points[0].AxisLabel = "N America";
                Chart1.Series[0].Points[1].AxisLabel = "S America";
                Chart1.Series[0].Points[2].AxisLabel = "Europe";
                Chart1.Series[0].Points[3].AxisLabel = "Asia";

                // Remove custom attributes
                Chart1.Series[0].CustomProperties = "";

                // Recalculate and repaint chart
                Chart1.ChartAreas[0].RecalculateAxesScale();
                Chart1.Invalidate();

                return;
            }

            // Set Label style for pie chart
            Chart1.Series[0].CustomProperties = "LabelStyle=outside";

            // Remove gradient for data points
            Chart1.Series[0].BackGradientStyle = GradientStyle.None;


            switch (result.PointIndex)
            {
                // N America
                case 0:
                    // Add data points
                    Chart1.Series[0].ChartType = SeriesChartType.Pie;
                    Chart1.Series[0].Points.Add(4);
                    Chart1.Series[0].Points.Add(3);
                    Chart1.Series[0].Points.Add(2);
                    Chart1.Series[0].Points.Add(1);
                    // Set Axis labels
                    Chart1.Series[0].Points[0].AxisLabel = "United States";
                    Chart1.Series[0].Points[1].AxisLabel = "Mexico";
                    Chart1.Series[0].Points[2].AxisLabel = "Canada";
                    Chart1.Series[0].Points[3].AxisLabel = "Guatemala";

                    break;
                // S America
                case 1:
                    // Add data points
                    Chart1.Series[0].ChartType = SeriesChartType.Pie;
                    Chart1.Series[0].Points.Add(4);
                    Chart1.Series[0].Points.Add(3);
                    Chart1.Series[0].Points.Add(2);
                    Chart1.Series[0].Points.Add(1);

                    // Set Axis labels
                    Chart1.Series[0].Points[0].AxisLabel = "Brazil";
                    Chart1.Series[0].Points[1].AxisLabel = "Colombia";
                    Chart1.Series[0].Points[2].AxisLabel = "Argentina";
                    Chart1.Series[0].Points[3].AxisLabel = "Peru";

                    break;
                // Europe
                case 2:
                    // Add data points
                    Chart1.Series[0].ChartType = SeriesChartType.Pie;
                    Chart1.Series[0].Points.Add(8);
                    Chart1.Series[0].Points.Add(3);
                    Chart1.Series[0].Points.Add(2);
                    Chart1.Series[0].Points.Add(1);

                    // Set Axis labels
                    Chart1.Series[0].Points[0].AxisLabel = "Russia";
                    Chart1.Series[0].Points[1].AxisLabel = "Germany";
                    Chart1.Series[0].Points[2].AxisLabel = "Turkey";
                    Chart1.Series[0].Points[3].AxisLabel = "France";

                    break;
                // Asia
                case 3:
                    // Add data points
                    Chart1.Series[0].ChartType = SeriesChartType.Pie;
                    Chart1.Series[0].Points.Add(4);
                    Chart1.Series[0].Points.Add(4);
                    Chart1.Series[0].Points.Add(1);
                    Chart1.Series[0].Points.Add(1);
                    

                    // Set Axis labels
                    Chart1.Series[0].Points[0].AxisLabel = "China";
                    Chart1.Series[0].Points[1].AxisLabel = "India";
                    Chart1.Series[0].Points[2].AxisLabel = "Indonesia";
                    Chart1.Series[0].Points[3].AxisLabel = "Pakistan";
                    

                    break;
            }

            Chart1.ChartAreas[0].RecalculateAxesScale();
            Chart1.Invalidate();
        }

        /// <summary>
        /// Mouse Move Event
        /// </summary>
        private void chart1_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            // Call Hit Test Method
            HitTestResult result = Chart1.HitTest(e.X, e.Y);

            // Reset Data Point Attributes
            foreach (DataPoint point in Chart1.Series[0].Points)
            {
                point.BackHatchStyle = ChartHatchStyle.None;
                point.BorderWidth = 1;
            }

            // If a Data Point or a Legend item is selected.
            if
            (result.ChartElementType == ChartElementType.DataPoint ||
                result.ChartElementType == ChartElementType.LegendItem)
            {
                // Set cursor type 
                this.Cursor = Cursors.Hand;

                // Find selected data point
                DataPoint point = Chart1.Series[0].Points[result.PointIndex];

                // Set End Gradient Color to White
                point.BackSecondaryColor = Color.White;

                // Set selected hatch style
                point.BackHatchStyle = ChartHatchStyle.Percent25;

                // Increase border width
                point.BorderWidth = 2;
            }
            else
            {
                // Set default cursor
                this.Cursor = Cursors.Default;
            }

        }

        // Load Form
        private void Form1_Load(object sender, System.EventArgs e)
        {
            // Set Chart Type
            Chart1.Series[0].ChartType = SeriesChartType.Column;

            // Add Data Points
            Chart1.Series[0].Points.Add(4);
            Chart1.Series[0].Points.Add(5);
            Chart1.Series[0].Points.Add(7);
            Chart1.Series[0].Points.Add(6);

            // Add Axis label
            Chart1.Series[0].Points[0].AxisLabel = "N America";
            Chart1.Series[0].Points[1].AxisLabel = "S America";
            Chart1.Series[0].Points[2].AxisLabel = "Europe";
            Chart1.Series[0].Points[3].AxisLabel = "Asia";

            // Remove custom attributes
            Chart1.Series[0].CustomProperties = "";

        }

        private void chart1_GetToolTipText(object sender, System.Windows.Forms.DataVisualization.Charting.ToolTipEventArgs e)
        {
         

        }


    }

}
