﻿using De.TorstenMandelkow.MetroChart;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using TimTracker.TrackerService;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq;
using TimTracker.Common;

namespace TimTracker
{
    public sealed partial class DashboardView 
    {
        public DashboardView()
        {
            InitializeComponent();
            //this.DataContext = new MainViewModel();
           // GetChart();
        }
        private  void GetChart(string filter=null)
        {
            //PieChart pi = new PieChart();
            //EndPointIdentity 
            TrackerServiceClient client = new TrackerServiceClient();
            
            Task<TimActivities> activities =  client.GetActivitiesAsync(null);
            //TimActivities act = await activities;
            if(activities!=null)
            {
                var re = activities.Result;
            
                var result = from p in re.activities
                             join q in re.pInfo on p.ProjectID equals q.ProjectID
                             group p by new { q.ProjectName, p.ActivityStartTime } into g
                             select new
                             {
                                 ActivityTime = g.Key.ActivityStartTime,
                                 Name = g.Key.ProjectName,
                                 Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.TimeSpent.Value))
                             };
                if(string.IsNullOrEmpty(filter))
                {
                    //result = from r in result where r.ActivityTime.Value equals filter select r;
                }
                MainViewModel main = new MainViewModel();
                foreach (var re1 in result)
                {
                    main.ProjectsInfo.Add(new ProjectInf { Name = re1.Name, Count = re1.Count.TotalSeconds });
                }
                this.DataContext = main;
             
            }
        }

        private void RadioButton_Checked(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            RadioButton rb = (RadioButton)sender;
            if(rb.IsChecked == true)
            {
                if (rb.Name == "rbPie")
                {
                    //Frist time the window loaded stack panels are null 
                    if (PiePanel != null)
                        PiePanel.Visibility = Visibility.Visible;
                    if (BarPanel!=null)
                        BarPanel.Visibility = Visibility.Collapsed;
                    if (ColumnChartPanel != null)
                        ColumnChartPanel.Visibility = Visibility.Collapsed;
                }
                if (rb.Name == "rbBar")
                {
                    if (BarPanel != null)
                        BarPanel.Visibility = Visibility.Visible;
                    PiePanel.Visibility = Visibility.Collapsed;
                    ColumnChartPanel.Visibility = Visibility.Collapsed;                    
                }
                if (rb.Name == "rbTable")
                {
                    if (ColumnChartPanel != null)
                        ColumnChartPanel.Visibility = Visibility.Visible;
                    PiePanel.Visibility = Visibility.Collapsed;
                    BarPanel.Visibility = Visibility.Collapsed;
                }
            }           
        }

        private void rbtOnDay_Checked(object sender, RoutedEventArgs e)
        {
            MainViewModel main = null;
            RadioButton rbt = (RadioButton)sender;
            string filter = string.Empty;
            if (rbt.Name == "rbtOnDay")
            {
                main = ChartData.GetData(dtOnDay.Date.Date);
            }
            else if (rbt.Name == "rbtBwtDays")
            {
                main = ChartData.GetData(dtFrom.Date.Date,dtTo.Date.Date);
            }
            else if (rbt.Name == "rbtWeekly")
            {
                main = ChartData.GetWeeklyData();
            }
            else if (rbt.Name == "rbtMonth")
            {
                main = ChartData.GetMonthlyData();
            }
            else if (rbt.Name == "rbtQuarter")
            {
                main = ChartData.GetQuarterlyData();
            }
            else if (rbt.Name == "rbtYear")
            {
                main = ChartData.GetYearlyData();
            }
            else if (rbt.Name == "rbtFiscalYear")
            {

            }
            this.DataContext = main;
        }

        private void btnDetailsView_Click(object sender, RoutedEventArgs e)
        {
            NavigateService.Instance.Navigate(typeof(ProjectDetailsView), typeof(MasterPage)); 
        }       
        
    }
    public class MainViewModel
    {
        private readonly ObservableCollection<ProjectInf> _populations = new ObservableCollection<ProjectInf>();
        public ObservableCollection<ProjectInf> ProjectsInfo
        {
            get
            {
                return _populations;
            }
        }

        public MainViewModel()
        {
            //_populations.Add(new Population() { Name = "China", Count = 1340 });
            //_populations.Add(new Population() { Name = "India", Count = 1220 });
            //_populations.Add(new Population() { Name = "United States", Count = 309 });
            //_populations.Add(new Population() { Name = "Indonesia", Count = 240 });
            //_populations.Add(new Population() { Name = "Brazil", Count = 195 });
            //_populations.Add(new Population() { Name = "Pakistan", Count = 174 });
            //_populations.Add(new Population() { Name = "Nigeria", Count = 158 });
            //_populations.Add(new Population() { Name = "Australia", Count = 158 });
        }
    }
    public class ProjectInf : INotifyPropertyChanged
    {
        private string _name = string.Empty;
        private Double _count ;

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
                NotifyPropertyChanged("Name");
            }
        }

        public Double Count
        {
            get
            {
                return _count;
            }
            set
            {
                _count = value;
                NotifyPropertyChanged("Count");
            }

        }

        public event PropertyChangedEventHandler PropertyChanged;

        private void NotifyPropertyChanged([CallerMemberName] String propertyName = "")
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }

}
