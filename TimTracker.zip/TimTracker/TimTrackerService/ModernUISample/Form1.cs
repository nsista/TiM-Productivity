﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MetroFramework;
using System.IO;
using System.Xml;
using System.Collections;
using System.Diagnostics;
using System.Xml.Serialization;
using MetroFramework.Controls;

namespace ModernUISample
{
    public partial class Form1 : MetroFramework.Forms.MetroForm
    {
        #region Variables Declaration
        public static string appName, prevvalue;
        public static Stack applnames;
        public static Hashtable applhash;
        public static DateTime applfocustime;
        public static string appltitle;
        public static SerializableDictionary<string, ProcessActiveLogger> ProcessTrace;
        //public static Form1 form1;
        public static string tempstr;
        public TimeSpan applfocusinterval;
        public DateTime logintime;
        public static List<string> KeyWords = null;
        public static StringBuilder strKeyWords = null;
        public static string AppPath = null;
        #endregion

        public Form1()
        {
            InitializeComponent();
           
        }
              
        private void metroUserControl1_Load(object sender, EventArgs e)
        {

        }
        //[STAThread]
        //static void Main()
        //{
        //    applnames = new Stack();
        //    applhash = new Hashtable();
        //    KeyWords = new List<string>();
        //    ProcessTrace = new SerializableDictionary<string, ProcessActiveLogger>();
        //    strKeyWords = new StringBuilder();
        //    Application.Run(new InteractiveChart());          
        //}
        private void timer1_Tick(object sender, System.EventArgs e)
        {
            //This is used to monitor and save active application's  details in Hashtable for future saving in xml file...
            try
            {
                bool isNewAppl = false;
                IntPtr hwnd = APIFuncs.getforegroundWindow();
                Int32 pid = APIFuncs.GetWindowProcessID(hwnd);
                Process p = Process.GetProcessById(pid);
                appName = p.ProcessName;
                appltitle = APIFuncs.ActiveApplTitle().Trim().Replace("\0", "");
                if (!applnames.Contains(appltitle + "$$$!!!" + appName) && !string.IsNullOrEmpty(strKeyWords.ToString()) && this.isKeywordExists(appltitle))
                {
                    applnames.Push(appltitle + "$$$!!!" + appName);
                    applhash.Add(appltitle + "$$$!!!" + appName, 0);
                    ProcessActiveLogger ProcLog = new ProcessActiveLogger();
                    ProcLog.ProcessName = appltitle + "$$$!!!" + appName;
                    ProcessTrace.Add(appltitle + "$$$!!!" + appName, ProcLog);
                    isNewAppl = true;
                }
               
                if (prevvalue != (appltitle + "$$$!!!" + appName))
                {
                    IDictionaryEnumerator en = applhash.GetEnumerator();
                    applfocusinterval = DateTime.Now.Subtract(applfocustime);
                    while (en.MoveNext())
                    {
                        if (en.Key.ToString() == prevvalue)
                        {
                            double prevseconds = Convert.ToDouble(en.Value);
                            applhash.Remove(prevvalue);
                            applhash.Add(prevvalue, (applfocusinterval.TotalSeconds + prevseconds));
                            break;
                        }
                    }
                    if (prevvalue != null)
                    {
                        ProcessActiveLogger PrevProcLog = new ProcessActiveLogger();
                        ProcessTrace.TryGetValue(prevvalue, out PrevProcLog);
                        if (PrevProcLog != null)
                        {
                            ProcessActivity procActivity = new ProcessActivity();
                            procActivity.ActivityTime = DateTime.Now;
                            procActivity.TotalActiveSessionTime = (int)applfocusinterval.TotalSeconds;
                            List<ProcessActivity> LstpActivity = PrevProcLog.ProcActivity;
                            if (LstpActivity == null)
                                LstpActivity = new List<ProcessActivity>();
                            PrevProcLog.ProcActivity = LstpActivity;
                            PrevProcLog.ProcActivity.Add(procActivity);
                        }
                    }
                    //ProcessActiveLogger latestProcLog = new ProcessActiveLogger();
                    //ProcessTrace.TryGetValue(appltitle + "$$$!!!" + appName, out latestProcLog);
                    //ProcessActivity NewActivity = new ProcessActivity();
                    //NewActivity.ActivityTime = DateTime.Now;
                    //List<ProcessActivity> NewLstpActivity = PrevProcLog.ProcActivity;
                    //if (NewLstpActivity == null)
                    //    NewLstpActivity = new List<ProcessActivity>();
                    //latestProcLog.ProcActivity = NewLstpActivity;
                    //latestProcLog.ProcActivity.Add(NewActivity);

                    prevvalue = appltitle + "$$$!!!" + appName;
                    applfocustime = DateTime.Now;
                }
                else
                {
                    //if (ProcessTrace.ContainsKey(prevvalue))
                    //{
                    //    ProcessActiveLogger activity = null;
                    //    ProcessTrace.TryGetValue(prevvalue, out activity);
                    //    ProcessActivity procActivity = activity.ProcActivity.LastOrDefault<ProcessActivity>();
                    //    TimeSpan ts = DateTime.Now.Subtract(procActivity.ActivityTime);
                    //    procActivity.TotalActiveSessionTime = (int)ts.TotalSeconds;
                    //}
                }
                if (isNewAppl)
                    applfocustime = DateTime.Now;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ":" + ex.StackTrace);
            }
        }
        private bool isKeywordExists(string app)
        {
            string[] keys = strKeyWords.ToString().Split(';');
            foreach (string key in keys)
            {
                if (app.Contains(key))
                    return true;
            }
            return false;
        }
        private void Form1_Closed(object sender, System.EventArgs e)
        {
            //This is activated on click on Exit menu item and to show actual and calculated time spent on all applications
            //opened so far and to open IE to show xml contents....
            try
            {
                SaveandShowDetails();
                TimeSpan timeinterval = DateTime.Now.Subtract(logintime);
                System.Diagnostics.EventLog.WriteEntry("Application Watcher Total Time Details", timeinterval.Hours + " Hrs " + timeinterval.Minutes + " Mins", System.Diagnostics.EventLogEntryType.Information);
                MessageBox.Show("Actual Time Spent :" + timeinterval.Hours + " Hrs " + timeinterval.Minutes + " Mins", "Application Watcher Total Time Details");

                StreamReader freader = new StreamReader(AppPath + @"\appldetails.xml");
                XmlTextReader xmlreader = new XmlTextReader(freader);
                string tottime = "";
                while (xmlreader.Read())
                {
                    if (xmlreader.NodeType == XmlNodeType.Element && xmlreader.Name == "TotalSeconds")
                    {
                        tottime += ";" + xmlreader.ReadInnerXml().ToString();
                    }
                }
                string[] tottimes = tottime.Split(';');
                long totsecs = 0;
                foreach (string str in tottimes)
                {
                    if (str != string.Empty)
                    {
                        if (str.IndexOf("Seconds") != -1)
                        {
                            totsecs += Convert.ToInt64(str.Substring(0, str.Length - 8));

                        }
                        else
                        {
                            totsecs += Convert.ToInt64(str.Substring(0, str.Length - 8)) * 60;
                        }
                    }
                }
                MessageBox.Show((totsecs / 60) + " Minutes");
                showdetailsinIE();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #region User-defined Methods...
        private void showdetailsinIE()
        {
            //To create XSL file,if it is not existing....
            if (!File.Exists(AppPath + @"\appl_xsl.xsl"))
            {
                File.Create(AppPath + @"\appl_xsl.xsl").Close();
                string xslcontents = "<?xml version=\"1.0\" encoding=\"ISO-8859-1\"?><xsl:stylesheet version=\"1.0\" xmlns:xsl=\"http://www.w3.org/1999/XSL/Transform\"><xsl:template match=\"/\"> <html> <body>  <h2>My Applications Details</h2>  <table border=\"1\"> <tr bgcolor=\"#9acd32\">  <th>Window Title</th>  <th>Process Name</th>  <th>Total Time</th> </tr> <xsl:for-each select=\"ApplDetails/Application_Info\"><xsl:sort select=\"ApplicationName\"/> <tr>  <td><xsl:value-of select=\"ProcessName\"/></td>  <td><xsl:value-of select=\"ApplicationName\"/></td>  <td><xsl:value-of select=\"TotalSeconds\"/></td> </tr> </xsl:for-each>  </table> </body> </html></xsl:template></xsl:stylesheet>";
                StreamWriter xslwriter = new StreamWriter(AppPath + @"\appl_xsl.xsl");
                xslwriter.Write(xslcontents);
                xslwriter.Flush();
                xslwriter.Close();
            }
            //TO show the contents of xml file in IE with a proper xsl....
            System.Diagnostics.Process ie = new Process();
            System.Diagnostics.ProcessStartInfo ieinfo = new ProcessStartInfo(@"C:\Program Files\Internet Explorer\iexplore.exe", AppPath + @"\appldetails.xml");
            ie.StartInfo = ieinfo;
            bool started = ie.Start();
            Application.Exit();
        }
        private void TestFocusedChanged()
        {
            //This is used to handle hashtable,if its length is 1.It means number of active applications is only one....
            try
            {
                if (applhash.Count == 1)
                {
                    IDictionaryEnumerator en = applhash.GetEnumerator();
                    applfocusinterval = DateTime.Now.Subtract(applfocustime);

                    while (en.MoveNext())
                    {
                        if (en.Key.ToString() == appltitle + "$$$!!!" + appName)
                        {
                            applhash.Remove(appltitle + "$$$!!!" + appName);
                            applhash.Add(appltitle + "$$$!!!" + appName, applfocusinterval.TotalSeconds);
                            break;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        private void BindGrid()
        {
            //This is used to bind grid with update contents of xml file....
            SaveandShowDetails();
            DataSet ds = new DataSet();
            ds.ReadXml(AppPath + @"\appldetails.xml");
            //dataGrid1.DataSource = ds;
            if(ds.Tables.Count>0)
            metroGrid1.DataSource = ds.Tables[0];
            DataSet ds1 = new DataSet();
            if(File.Exists(AppPath + @"\ProcessTrace.xml"))
            ds1.ReadXml(AppPath + @"\ProcessTrace.xml");
            if(ds1.Tables.Count>0)
            FillTreeView(ds1);
            
        }
        private void FillTreeView(DataSet ds)
        {
            DataTable dt = ds.Tables["ProcessActiveLogger"];
            DataTable dt1 = ds.Tables["ProcessActivity"];

            var groupJoinQuery =
    from order in dt.AsEnumerable()
    join detail in dt1.AsEnumerable()
    on order.Field<int>("ProcessActiveLogger_Id") equals
        detail.Field<int>("ProcActivity_Id") //into prodGroup
    // select prodGroup;
    select new
{
    ProcessName =
        order.Field<string>("ProcessName"),
    ActivityTime =
        detail.Field<string>("ActivityTime"),
    ActivityDate =
        detail.Field<string>("TotalActiveSessionTime"),
    // ProcessID =
    //     order.Field<int>("ProcessActiveLogger_Id")
};
            var grp = from g in groupJoinQuery
                      group g by g.ProcessName into g1
                      select g1;
            treeView1.Nodes.Clear();
            TreeNode root = new TreeNode("Process Activity");
            treeView1.Nodes.Add(root);            
            foreach (var prodGrouping in grp)
            {
                TreeNode node = new TreeNode(prodGrouping.Key.Split("$$$!!!".ToCharArray())[0]);

                foreach (var item in prodGrouping)
                {
                    TreeNode child = new TreeNode(item.ActivityTime);
                    TreeNode child1 = new TreeNode(item.ActivityDate);
                    child.Nodes.Add(child1);
                    child.ImageIndex = 1;
                    child1.ImageIndex = 2;
                    node.Nodes.Add(child);
                }
                root.Nodes.Add(node);
            }
        }
        private void SaveandShowDetails()
        {
            //This is used to save contents of hashtable in a xml file....
            try
            {
                TestFocusedChanged();
                System.IO.StreamWriter writer = new System.IO.StreamWriter(AppPath + @"\appldetails.xml", false);
                IDictionaryEnumerator en = applhash.GetEnumerator();
                writer.Write("<?xml version=\"1.0\"?>");
                writer.WriteLine("");
                writer.Write("<?xml-stylesheet type=\"text/xsl\" href=\"appl_xsl.xsl\"?>");
                writer.WriteLine("");
                writer.Write("<ApplDetails>");
                while (en.MoveNext())
                {
                    if (!en.Value.ToString().Trim().StartsWith("0"))
                    {
                        writer.Write("<Application_Info>");
                        writer.Write("<ProcessName>");
                        string processname = "<![CDATA[" + en.Key.ToString().Trim().Substring(0, en.Key.ToString().Trim().LastIndexOf("$$$!!!")).Trim() + "]]>";
                        processname = processname.Replace("\0", "");
                        writer.Write(processname);
                        writer.Write("</ProcessName>");

                        writer.Write("<ApplicationName>");
                        string applname = "<![CDATA[" + en.Key.ToString().Trim().Substring(en.Key.ToString().Trim().LastIndexOf("$$$!!!") + 6).Trim() + "]]>";

                        writer.Write(applname);
                        writer.Write("</ApplicationName>");

                        writer.Write("<TotalSeconds>");
                        if ((Convert.ToDouble(en.Value) / 60) < 1)
                        {
                            writer.Write(Convert.ToInt32((Convert.ToDouble(en.Value))) + " Seconds");
                        }
                        else
                        {
                            writer.Write(Convert.ToInt32((Convert.ToDouble(en.Value)) / 60) + " Minutes");
                        }
                        writer.Write("</TotalSeconds>");
                        writer.Write("</Application_Info>");
                    }
                }
                writer.Write("</ApplDetails>");
                writer.Flush();
                writer.Close();

                XmlSerializer serializer = new XmlSerializer(typeof(SerializableDictionary<string, ProcessActiveLogger>));               
                using (TextWriter textWriter = new StreamWriter(AppPath + "/ProcessTrace.xml"))
                {
                    serializer.Serialize(textWriter, ProcessTrace);

                    textWriter.Close();
                }
                //System.Xml.Serialization.XmlSerializer x = new System.Xml.Serialization.XmlSerializer(ProcessTrace.GetType());
                //x.Serialize(Console.Out, ProcessTrace);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
        #endregion
        private void notifyIcon1_Click(object sender, System.EventArgs e)
        {
            //This is used to show and hide Form....
            try
            {
                if (this.Visible == true)
                {
                    this.Visible = false;
                    notifyIcon1.Text = "Application Watcher is in Invisible Mode";
                }
                else
                {
                    this.Visible = true;
                    this.Focus();
                    this.WindowState = FormWindowState.Normal;
                    notifyIcon1.Text = "Application Watcher is in Visible Mode";
                    BindGrid();
                }
            }
            catch { }
        }
        private void Form1_Load(object sender, System.EventArgs e)
        {
            this.Visible = false;
            notifyIcon1.Text = "Application Watcher is in Invisible Mode";
            logintime = DateTime.Now;
            metroTabControl1.SelectedIndex = 0;
            AppPath = Application.StartupPath + @"\Resources";
            if (!System.IO.Directory.Exists(AppPath))
            {
                System.IO.Directory.CreateDirectory(AppPath);
            }
            //this.Text = "Login Time is at :" + DateTime.Now.ToLongTimeString();
            if (!System.IO.File.Exists(AppPath + @"\appldetails.xml"))
            {
                System.IO.File.Create(AppPath + @"\appldetails.xml").Close();
            }
            if (!System.IO.File.Exists(AppPath + @"\Clientdetails.xml"))
            {
                System.IO.File.Create(AppPath + @"\Clientdetails.xml").Close();
                XmlDocument doc = new XmlDocument();
                doc.LoadXml("<ClientDetails></ClientDetails>");
                doc.Save(AppPath + @"\Clientdetails.xml");
            }
            UpdateKeyWords();
            metroDateTime1.ShowUpDown = true;
        }
        private void UpdateKeyWords()
        {
            if (System.IO.File.Exists(AppPath + @"\Clientdetails.xml"))
            {
                DataSet ds = new DataSet();
                ds.ReadXml(AppPath + @"\Clientdetails.xml");
                if (ds.Tables.Count > 0)
                {
                    int i = 0;
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        KeyWords.Add(dr["ClientName"].ToString());
                        strKeyWords.Append(dr["ClientName"].ToString());
                        if (i < ds.Tables[0].Rows.Count - 1)
                            strKeyWords.Append(";");
                        i++;
                    }
                }
            }
        }
        private void menuItem2_Click(object sender, System.EventArgs e)
        {
            //This is activated on click on Refresh menu item to load grid with present contents of xml file....
            BindGrid();
        }
        private void menuItem3_Click(object sender, System.EventArgs e)
        {
            //This is activated on click on Exit menu item and to show actual and calculated time spent on all applications
            //opened so far and to open IE to show xml contents....
            SaveandShowDetails();
            TimeSpan timeinterval = DateTime.Now.Subtract(logintime);
            System.Diagnostics.EventLog.WriteEntry("Application Watcher Total Time Details", timeinterval.Hours + " Hrs " + timeinterval.Minutes + " Mins", System.Diagnostics.EventLogEntryType.Information);
            MessageBox.Show("Actual Time Spent :" + timeinterval.Hours + " Hrs " + timeinterval.Minutes + " Mins", "Application Watcher Total Time Details");

            StreamReader freader = new StreamReader(AppPath + @"\appldetails.xml");
            XmlTextReader xmlreader = new XmlTextReader(freader);
            string tottime = "";
            while (xmlreader.Read())
            {
                if (xmlreader.NodeType == XmlNodeType.Element && xmlreader.Name == "TotalSeconds")
                {
                    tottime += ";" + xmlreader.ReadInnerXml().ToString();
                }
            }
            string[] tottimes = tottime.Split(';');
            long totsecs = 0;
            foreach (string str in tottimes)
            {
                if (str != string.Empty)
                {
                    if (str.IndexOf("Seconds") != -1)
                    {
                        totsecs += Convert.ToInt64(str.Substring(0, str.Length - 8));

                    }
                    else
                    {
                        totsecs += Convert.ToInt64(str.Substring(0, str.Length - 8)) * 60;
                    }
                }
            }
            MessageBox.Show((totsecs / 60) + " Minutes");
            showdetailsinIE();
        }

        private void metroTile1_Click(object sender, EventArgs e)
        {
            Form2 frm = new Form2();
            frm.ShowDialog();
            UpdateKeyWords();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void metroGrid2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void metroTabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            MetroTabControl tab = (MetroTabControl)sender;
            if (tab.SelectedIndex == 1)
            {
                metroGrid2.DataSource = Class1.GetAllCalendarItems();
            }


        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            SaveandShowDetails();
            DataSet ds = new DataSet();
            ds.ReadXml(AppPath + @"\appldetails.xml");
            if (ds.Tables.Count == 0)
            {
                DataTable dt = new DataTable("Application_Info");
                dt.Columns.Add("ProcessName");
                dt.Columns.Add("ApplicationName");
                dt.Columns.Add("TotalSeconds");
                DataRow dr = dt.NewRow();
                dr["ProcessName"] = metroComboBox1.Text;
                dr["ApplicationName"] = "Offline Activity";
                dr["TotalSeconds"] = metroComboBox2.Text + "H" + metroComboBox3.Text + "M";
                dt.Rows.Add(dr);
                ds.Tables.Add(dt);
                metroGrid1.DataSource = ds;
                ds.WriteXml(AppPath + @"\appldetails.xml");
            }
        }


    }
}
