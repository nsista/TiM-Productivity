﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TimTrackerService;

namespace TestTimTracker
{
    class Program
    {
        static void Main(string[] args)
        {
            TimTrackerService.TrackerService ts = new TimTrackerService.TrackerService();
            while (true)
                ts.ActivityLogger();
            //char[] alpha = new char[]{ 'A', 'B', 'C', 'D' };
            //foreach (char c in alpha)
            //{
            //    ProjectInfo pinfo = new ProjectInfo();
            //    pinfo.ProjectID = Guid.NewGuid();
            //    pinfo.ProjectName = "Project " + c;
            //    pinfo.Status = true;
            //    pinfo.CreatedDate = DateTime.Now;
            //    ts.SaveProjectInfo(pinfo);
            //}
           
        }
    }
}
