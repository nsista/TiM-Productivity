﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using TimTracker.TrackerService;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using ZeroProximity.Controls;
namespace TimTracker
{
    public sealed partial class MainPage
    {
        public List<ProjectInfo> projInfo;
        public MainPage()
        {
            InitializeComponent();
            projInfo = new List<ProjectInfo>();
           // ViewModel vm = new ViewModel();
           // ProjectGrid.ItemsSource = vm.Data;
            //Accordion AccPrj = new Accordion();
            //AccordionItem item = new AccordionItem();
            //item.Header = "Project A12";
            //StackPanel sp = new StackPanel();
            //sp.Children.Add(new TextBlock{Text="Content1"} );
            //item.Content=sp;
            //AccPrj.Items.Add(item);
            //(pnlAcc).Children.Add(AccPrj);
            CreateProjectTree();
        }
        private void CreateProjectTree()
        {
            TrackerServiceClient client = new TrackerServiceClient();

            Task<TimActivities> activities = client.GetActivitiesAsync(null);
            //TimActivities act = await activities;
            if (activities != null)
            {
                var result = activities.Result;

                var pInfo = result.pInfo.OrderBy(a=> a.ProjectName);
                var categories = result.categories;
                var activitie = result.activities;
                ScrollViewer sw = new ScrollViewer();
                sw.VerticalScrollMode = ScrollMode.Auto;
                //(pnlAcc).Children.Add(sw);
                Accordion accProject = new Accordion();                
                accProject.HorizontalAlignment = HorizontalAlignment.Stretch;
                accProject.SelectionMode = AccordionSelectionMode.ZeroOrOne;
                foreach (ProjectInfo prj in pInfo)
                {
                    AccordionItem project = new AccordionItem();
                    
                    project.Header = prj.ProjectName;
                    project.FontSize = 20;
                    //project.HorizontalAlignment = HorizontalAlignmen
                    project.Foreground = new Windows.UI.Xaml.Media.SolidColorBrush(Windows.UI.Colors.Black);
                    //project.Key = prj.ProjectID;
                    //project.IsDraggable = false;
                    StackPanel spProjects = new StackPanel();
                    foreach (Category ca in categories)
                    {
                        AccordionItem category = new AccordionItem();
                       // category.Header = ca.CategoryName;
                        category.Margin = new Thickness(10, 0, 0, 0);
                        //category.Key = ca.ID;
                        // category.IsDraggable = false;
                        var rslt = from activity in activitie
                                   where activity.ProjectID == prj.ProjectID && ca.CategoryTypes.Contains(activity.ProcessName)
                                   select activity;
                        var totalTime = (from t in rslt.AsEnumerable()
                                         select new
                                         {
                                             t.TimeSpent
                                         }).Aggregate(new TimeSpan(0), (p, v) => p.Add(v.TimeSpent.Value));
                        Grid g1 = new Grid();
                        g1.Children.Add(new TextBlock { Text = ca.CategoryName, HorizontalAlignment = HorizontalAlignment.Left });
                        g1.Children.Add(new TextBlock { Text = "[ " + totalTime.ToString(@"h\:mm\:ss") + " ]", HorizontalAlignment = HorizontalAlignment.Right });
                        category.Header = g1;
                        StackPanel spCatregory = new StackPanel();                        
                        foreach (ActivityLogger a in rslt)
                        {
                            Grid g = new Grid();
                            g.Children.Add(new TextBlock { Text = a.ActivityName, HorizontalAlignment = HorizontalAlignment.Left });
                            g.Children.Add(new TextBlock { Text = "[ " + a.TimeSpent.Value.ToString(@"h\:mm\:ss") + " ]", HorizontalAlignment = HorizontalAlignment.Right });
                            spCatregory.Children.Add(g);
                        }
                        category.Content = spCatregory;
                        spProjects.Children.Add(category);
                    }
                    project.Content = spProjects;
                    accProject.Items.Add(project);                    
                }
                sw.Content = accProject;
                (pnlAcc).Children.Add(sw);
            }
        }
        private void ToggleSwitch_Toggled(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {

        }

        private void btnSumit_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            //ProjectGrid.ItemsSource = null;
            //ProjectInfo info = new ProjectInfo();
            //info.ProjectName = txtProjectName.Text;            
            //info.track = rbtTrack.IsChecked.HasValue&&rbtTrack.IsChecked.Value==true?true:false;
            //projInfo.Add(info);
            //ProjectGrid.ItemsSource = projInfo;
            
        }
        public class Datum
        {
            public DateTime Date { get; set; }
            public string Year { get { return Date.ToString("yyy"); } }
            public string Month { get { return Date.ToString("MMMM"); } }
            public string Day { get { return Date.ToString("dd"); } }
            public string Weekday { get { return Date.ToString("dddd"); } }
        }

        public class ViewModel
        {
            public ViewModel()
            {
                // data
                var _Data = Enumerable.Range(1, 20)
                    .Select(x => new Datum { Date = DateTime.Now.Add(TimeSpan.FromDays(x * 14)) });
                Data = new ObservableCollection<Datum>(_Data);
            }
            public ObservableCollection<Datum> Data { get; private set; }
        }
        //public class ProjectInfo
        //{
        //    public string ProjectName {get;set;}
        //    public bool track { get; set; }
        //}
    }
}
