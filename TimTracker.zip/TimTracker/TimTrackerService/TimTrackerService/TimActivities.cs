﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TimTrackerService
{
    public class TimActivities
    {
        public List<ProjectInfo> pInfo{get;set;}
        public List<Category> categories { get; set; }
        public List<ActivityLogger> activities { get; set; }
    }
}
