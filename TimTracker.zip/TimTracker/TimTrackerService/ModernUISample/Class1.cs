﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;   
// to use Missing.Value

//TO DO: If you use the Microsoft Outlook 11.0 Object Library, uncomment the following line.
using Outlook = Microsoft.Office.Interop.Outlook;
using System.Windows.Forms;
using System.Data;

namespace ModernUISample
{
   /// <summary>
   /// Summary description for Class1.
   /// </summary>
   public class Class1
   {
      /// <summary>
      /// The main entry point for the application.
      /// </summary>
      public static void GetCalenderEvents()
      {
         try
         {
             GetAllCalendarItems();
            // Create the Outlook application.
            Outlook.Application oApp = new Outlook.Application();

            // Get the NameSpace and Logon information.
            // Outlook.NameSpace oNS = (Outlook.NameSpace)oApp.GetNamespace("mapi");
            Outlook.NameSpace oNS = oApp.GetNamespace("mapi");

            //Log on by using a dialog box to choose the profile.
            oNS.Logon(Missing.Value, Missing.Value, true, true); 

            //Alternate logon method that uses a specific profile.
            // TODO: If you use this logon method, 
            // change the profile name to an appropriate value.
            //oNS.Logon("YourValidProfile", Missing.Value, false, true); 
			
            // Get the Calendar folder.
            Outlook.MAPIFolder oCalendar = oNS.GetDefaultFolder(Outlook.OlDefaultFolders.olFolderCalendar);

            // Get the Items (Appointments) collection from the Calendar folder.
            Outlook.Items oItems = oCalendar.Items;
            
            // Get the first item.
            Outlook.AppointmentItem oAppt = (Outlook.AppointmentItem) oItems.GetFirst();


            // Show some common properties.
            Console.WriteLine("Subject: " + oAppt.Subject);
            Console.WriteLine("Organizer: " + oAppt.Organizer);
            Console.WriteLine("Start: " + oAppt.Start.ToString());
            Console.WriteLine("End: " + oAppt.End.ToString());
            Console.WriteLine("Location: " + oAppt.Location);
            Console.WriteLine("Recurring: " + oAppt.IsRecurring);
   
            //Show the item to pause.
            oAppt.Display(true);

            // Done. Log off.
            oNS.Logoff();

            // Clean up.
            oAppt = null;
            oItems = null;
            oCalendar = null;
            oNS = null;
            oApp = null;
         }

            //Simple error handling.
         catch (Exception e)
         {
            Console.WriteLine("{0} Exception caught.", e);
         }  

         //Default return value
         //return 0;
  
      }
      public static DataTable GetAllCalendarItems()
      {
          DataTable dt = new DataTable();
          dt.Columns.Add("Subject", typeof(string));
          dt.Columns.Add("DateOfAppointment", typeof(string));
          dt.Columns.Add("StartTime", typeof(string));
          dt.Columns.Add("EndTime", typeof(string));
          dt.Columns.Add("Location", typeof(string));
          
          Microsoft.Office.Interop.Outlook.Application oApp = null;
          Microsoft.Office.Interop.Outlook.NameSpace mapiNamespace = null;
          Microsoft.Office.Interop.Outlook.MAPIFolder CalendarFolder = null;
          Microsoft.Office.Interop.Outlook.Items outlookCalendarItems = null;

          oApp = new Microsoft.Office.Interop.Outlook.Application();
          mapiNamespace = oApp.GetNamespace("MAPI"); ;
          CalendarFolder = mapiNamespace.GetDefaultFolder(Microsoft.Office.Interop.Outlook.OlDefaultFolders.olFolderCalendar); outlookCalendarItems = CalendarFolder.Items;
          outlookCalendarItems.IncludeRecurrences = true;

          foreach (Microsoft.Office.Interop.Outlook.AppointmentItem item in outlookCalendarItems)
          {
              DataRow dr = dt.NewRow();
              if (item.IsRecurring)
              {
                  Microsoft.Office.Interop.Outlook.RecurrencePattern rp = item.GetRecurrencePattern();
                  DateTime first = new DateTime(2008, 8, 31, item.Start.Hour, item.Start.Minute, 0);
                  DateTime last = new DateTime(2008, 10, 1);
                  Microsoft.Office.Interop.Outlook.AppointmentItem recur = null;



                  for (DateTime cur = first; cur <= last; cur = cur.AddDays(1))
                  {
                      try
                      {
                          recur = rp.GetOccurrence(cur);
                          MessageBox.Show(recur.Subject + " -> " + cur.ToLongDateString());
                      }
                      catch
                      { }
                  }
              }
              else
              {
                  dr["Subject"] = item.Subject;
                  dr["DateOfAppointment"] = item.Start.ToShortDateString();
                  dr["StartTime"] = item.Start.ToShortTimeString();
                  dr["EndTime"] = item.End.ToShortTimeString();
                  dr["Location"] = item.Location;
                  dt.Rows.Add(dr);

                  //MessageBox.Show(item.Subject + " -> " + item.Start.ToLongDateString());
              }
          }
          return dt;
      }
   }
}
