﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using TimTracker.Common;
using TimTracker.TrackerService;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using TimTracker.Controls;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace TimTracker
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class ProjectDetailsView : Page
    {
        public List<int> Hours { get; set; }
        public List<int> Minutes { get; set; }
        private void SetHoursAndMinuts()
        {
            Hours = new List<int>();
            Minutes = new List<int>();
            for (int i=1;i<=60;i++)
            {
                if (i <= 12)
                    Hours.Add(i);
                Minutes.Add(i);
            }
        }
        public ProjectDetailsView()
        {
            this.InitializeComponent();
            ItemDetails messageData = new ItemDetails();
             TrackerServiceClient client = new TrackerServiceClient();

            Task<TimActivities> activities = client.GetActivitiesAsync(null);
            //TimActivities act = await activities;
            if (activities != null)
            {
                var result = activities.Result;

                var pInfo = result.pInfo.OrderBy(a => a.ProjectName);
                //lstProjects.ItemsSource = pInfo.ToList();
                lstAltListView.ItemsSource = pInfo.ToList();
                var categories = result.categories;
                var activitie = result.activities;
                cmbProjects.ItemsSource = pInfo.ToList();
                cmbCategories.ItemsSource = categories;
                cmbProjects.DisplayMemberPath = "ProjectName";
                cmbCategories.DisplayMemberPath = "CategoryName";
                SetHoursAndMinuts();
                cmbHours.ItemsSource = Hours;
                cmbMinutes.ItemsSource = Minutes;
                //ItemsByCategory.ItemsSource = activitie.ToList();
            }
           // List<GroupInfoList<object>> dataLetter = GetGroupsByCategory(null);
           // cvs2.Source = dataLetter;
            //ItemListView.ItemsSource = messageData.Collection;
            //lstProjects.ItemsSource = messageData.Collection;
           // ItemListView.SelectedIndex = 0;
        }
        private void rbtOnDay_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton rbt = (RadioButton)sender;
            string filter = string.Empty;
            if (rbt.Name == "rbtOnDay")
            {

            }
            else if (rbt.Name == "rbtBwtDays")
            {

            }
            else if (rbt.Name == "rbtWeekly")
            {

            }
            else if (rbt.Name == "rbtMonth")
            {

            }
            else if (rbt.Name == "rbtQuarter")
            {

            }
            else if (rbt.Name == "rbtYear")
            {

            }
            else if (rbt.Name == "rbtFiscalYear")
            {

            }
        }

        private void lstProjects_Tapped(object sender, TappedRoutedEventArgs e)
        {

           // e.base.Content.Transitions.
        }
        internal List<GroupInfoList<object>> GetGroupsByCategory(string ProjectID)
        {
            return ChartData.GetquarterlyData(ProjectID);
            //List<GroupInfoList<object>> groups = new List<GroupInfoList<object>>();
           
            //TrackerServiceClient client = new TrackerServiceClient();

            //Task<TimActivities> activities = client.GetActivitiesAsync(null);
            ////TimActivities act = await activities;
            //if (activities != null)
            //{
            //    var re = activities.Result;
            //    var val = from a in re.activities
            //              join b in re.pInfo on a.ProjectID equals b.ProjectID
            //              join c in re.categories on a.CategoryName equals c.CategoryName
            //              where a.ProjectID.Value.ToString() == ProjectID
            //              group a by new { c.CategoryName } into g
            //              select new
            //              {
            //                  GroupName = g.Key.CategoryName,
            //                  Items = g
            //              };
            //    foreach (var g in val)
            //    {
            //        GroupInfoList<object> info = new GroupInfoList<object>();
            //        info.Key = g.GroupName;
            //        foreach (var item in g.Items)
            //        {
            //            info.Add(item);
            //        }
            //        groups.Add(info);
            //    }
            //}

            //return groups;
        }

        private void lstAltListView_Tapped(object sender, TappedRoutedEventArgs e)
        {
            ListView lst = (ListView)sender;
            var item = (ProjectInfo) lst.SelectedItem;
            List<GroupInfoList<object>> dataLetter = GetGroupsByCategory(item.ProjectID.ToString());
            cvs2.Source = dataLetter;
        }
        // Handles the Click event on the Button inside the Popup control and 
        // closes the Popup. 
        private void ClosePopupClicked(object sender, RoutedEventArgs e)
        {
            // if the Popup is open, then close it 
            if (StandardPopup.IsOpen) { StandardPopup.IsOpen = false; }
        }

        // Handles the Click event on the Button on the page and opens the Popup. 
        private void ShowPopupOffsetClicked(object sender, RoutedEventArgs e)
        {
            // open the Popup if it isn't open already 
            if (!StandardPopup.IsOpen) { StandardPopup.IsOpen = true; }
        } 
    }
    public class GroupInfoList<T> : List<object>
    {
        public object Key { get; set; }
        public new IEnumerator<object> GetEnumerator()
        {
            return (System.Collections.Generic.IEnumerator<object>)base.GetEnumerator();
        }
    }

}
