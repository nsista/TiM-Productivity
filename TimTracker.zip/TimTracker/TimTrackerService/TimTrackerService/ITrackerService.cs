﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace TimTrackerService
{
    
    [ServiceContract]
    public interface ITrackerService
    {
        [OperationContract]
        List<ProjectInfo> GetProjectInfo();

        [OperationContract]
        void SaveActivity(ActivityLogger logger);

        [OperationContract]
        void SaveProjectInfo(ProjectInfo prjInfo);

        [OperationContract]
        TimActivities GetActivities(string userID);
        //[OperationContract]
        //void GetChartData(string whereClause);
        [OperationContract]
        object GetChartData(string period, DateTime? FromDate, DateTime? Todate);
    }


}
