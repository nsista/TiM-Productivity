﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceModel;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using TimTrackerService;


namespace TimTrackerWinService
{
    public partial class TimTrackerWinService : ServiceBase
    {
        internal static ServiceHost TimTrackerServiceHost = null;
        TrackerService tService = null;
        public TimTrackerWinService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            if (TimTrackerServiceHost != null)
            {
                TimTrackerServiceHost.Close();
            }
            try
            {
                 //Here is where we set the bit on the value in the registry.
                // Grab the subkey to our service
                RegistryKey ckey = Registry.LocalMachine.OpenSubKey(
                  @"SYSTEM\CurrentControlSet\Services\TimTrackerService", true);
                // Good to always do error checking!
                if (ckey != null)
                {
                    // Ok now lets make sure the "Type" value is there, 
                    //and then do our bitwise operation on it.
                    if (ckey.GetValue("Type") != null)
                    {
                        ckey.SetValue("Type", ((int)ckey.GetValue("Type") | 256));
                    }
                }
                TimTrackerServiceHost = new ServiceHost(typeof(TrackerService));
                TimTrackerServiceHost.Open();
                tService = new TrackerService();
                //while (true)
                //    tService.ActivityLogger();
                //TimTimer.Start();
            }
            catch (Exception ex)
            {
            }
            finally
            {
                
            }
        }

        protected override void OnStop()
        {
            if (TimTrackerServiceHost != null)
            {
                TimTrackerServiceHost.Close();
                TimTrackerServiceHost = null;
            }
        }

        private void TimTimer_Tick(object sender, EventArgs e)
        {
            //if (tService!=null)
            //while (true)
            //    tService.ActivityLogger();
        }
    }
}
