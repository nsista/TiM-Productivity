﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using TimTracker.TrackerService;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;

namespace TimTracker
{
    public sealed partial class MasterPage
    {
        public List<ProjectInfo> projInfo;
        public MasterPage()
        {
            InitializeComponent();
            TrackerServiceClient client = new TrackerServiceClient();
            var chartData = client.GetChartDataAsync("year", null, null);
            if(chartData!=null)
            {
              //var res = chartData.Result;
            }
            var activities = client.GetProjectInfoAsync();
            if (activities != null)
            {
                var result = activities.Result;
                var re = from r in result select r;
                //ProjectGrid.ItemsSource = re;
                lstAltListView.ItemsSource = re.ToList();
            }
            projInfo = new List<ProjectInfo>();
        }

        private void ButtonBase_OnClick1(object sender, RoutedEventArgs e)
        {
            //btnProjects.Foreground= 
            NavigateService.Instance.Navigate(typeof(MasterPage));
        }
        private void ButtonBase_OnClick2(object sender, RoutedEventArgs e)
        {
            NavigateService.Instance.Navigate(typeof(DashboardView), typeof(MasterPage));
        }
        private void ButtonBase_OnClick3(object sender, RoutedEventArgs e)
        {
            //NavigateService.Instance.Navigate(typeof(MainPage), typeof(MasterPage));           
            NavigateService.Instance.Navigate(typeof(Settings), typeof(MasterPage));  
        }
        private void ToggleSwitch_Toggled(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {

        }

        private void btnSumit_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            Button btn = (Button)sender;
            if (btn.Content.ToString() == "Submit")
            {
                if (!string.IsNullOrEmpty(txtProjectName.Text))
                {
                    lblValidation.Text = "";
                    TrackerServiceClient client = new TrackerServiceClient();
                    client.SaveProjectInfoAsync(new ProjectInfo { ProjectID = Guid.NewGuid(), ProjectName = txtProjectName.Text, Status = rbtTrack.IsChecked.Value, CreatedDate = DateTime.Now });
                }
                else
                    lblValidation.Text = "Please Enter Project ID / Client ID";
            }
            else if(btn.Content.ToString()=="Update")
            {
                ClearText();
            }           
        }
       
        private void ProjectGrid_DoubleTapped(object sender, Windows.UI.Xaml.Input.DoubleTappedRoutedEventArgs e)
        {

        }

        private void ProjectGrid_DoubleTapped_1(object sender, Windows.UI.Xaml.Input.DoubleTappedRoutedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //NavigateService.Instance.Navigate(typeof(ProjectDetailsView));
            NavigateService.Instance.Navigate(typeof(ProjectDetailsView), typeof(MasterPage));   
        }

        private void TextBlock_SelectionChanged(object sender, RoutedEventArgs e)
        {

        }

        private void lstAltListView_DoubleTapped(object sender, Windows.UI.Xaml.Input.DoubleTappedRoutedEventArgs e)
        {
            ListView lst = (ListView)sender;
            var item = (ProjectInfo)lst.SelectedItem;
            txtProjectName.Text = item.ProjectName;
            if(item.Status == true)
            {
                rbtTrack.IsChecked = true;
            }
            else
            {
                rbtStopTrack.IsChecked = true;
            }
            btnSubmit.Content = "Update";
            //List<GroupInfoList<object>> dataLetter = GetGroupsByCategory(item.ProjectID.ToString());
        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            ClearText();
        }
        private void ClearText()
        {
            txtProjectName.Text = "";
            rbtTrack.IsChecked = true;
            btnSubmit.Content = "Submit";
            lblValidation.Text = "";
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            NavigateService.Instance.Navigate(typeof(Settings), typeof(MasterPage));   
        }

        private void TextBlock_SelectionChanged_1(object sender, RoutedEventArgs e)
        {

        }
    }
}
