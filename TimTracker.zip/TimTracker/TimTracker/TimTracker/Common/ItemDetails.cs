﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Media.Imaging;

namespace TimTracker.Common
{
    public class ItemDetails
    {

        public ItemDetails()
        {

            Item item;

            Uri _baseUri = new Uri("ms-appx:///");

            item = new Item();

            item.Title = "Acer Aspire S3-391 Laptop";

            item.Price = "Rs. 66,754";

            item.SetImage(_baseUri, "Images/1.jpg");

            item.Content = "Core i7 (3G), 13.3 Inch4,  GB RAM, 500 GB HD, Win 7";



            item = new Item();

            item.Title = "Acer Aspire S3 Aspire S Laptop";

            item.Price = "Rs. 54,500";

            item.SetImage(_baseUri, "Images/2.jpg");

            item.Content = "Core i5 (2G), 13.3 Inch, 4 GB RAM, 320 GB HD, Win 7";

            Collection.Add(item);



            item = new Item();

            item.Title = "Acer Aspire One 725 Laptop";

            item.Price = "Rs. 19,499";

            item.SetImage(_baseUri, "Images/3.jpg");

            item.Content = "AMD APU Dual Core, 11.6 Inch, 2 GB RAM, 320 GB HD, Win 7";

            Collection.Add(item);



            item = new Item();

            item.Title = "Acer Aspire One AOD 270 NU.SGASI.003 Netbook";

            item.Price = "Rs. 16,560";

            item.SetImage(_baseUri, "Images/4.jpg");

            item.Content = "Atom Dual Core (2G), 10.1 Inch, 2 GB RAM, 320 GB HD, Linux";

            Collection.Add(item);



            item = new Item();

            item.Title = "Acer Aspire V3-571G Laptop";

            item.Price = "Rs. 38,455";

            item.SetImage(_baseUri, "Images/6.jpg");

            item.Content = "Core i3 (2G), 15.6 Inch, 4 GB RAM, 500 GB HD, Win 7";

            Collection.Add(item);

        }

        List<Item> collection = new List<Item>();



        public List<Item> Collection
        {

            get
            {

                return this.collection;

            }

        }

    }

}



public class Item
{

    private string _Title;

    public string Title
    {

        get
        {

            return this._Title;

        }

        set
        {

            this._Title = value;

        }

    }

    private string _Price;

    public string Price
    {

        get
        {

            return this._Price;

        }

        set
        {

            this._Price = value;

        }

    }

    private ImageSource _Image;

    public ImageSource Image
    {

        get
        {

            return this._Image;

        }

        set
        {

            this._Image = value;

        }

    }

    public void SetImage(Uri baseUri, String path)
    {

        Image = new BitmapImage(new Uri(baseUri, path));

    }

    private string _Link;

    public string Link
    {

        get
        {

            return this._Link;

        }

        set
        {

            this._Link = value;

        }

    }

    private string _Category;

    public string Category
    {

        get
        {

            return this._Category;

        }

        set
        {

            this._Category = value;

        }

    }

    private string _Description;

    public string Description
    {

        get
        {

            return this._Description;

        }

        set
        {

            this._Description = value;

        }

    }

    private string _Content;

    public string Content
    {

        get
        {

            return this._Content;

        }

        set
        {

            this._Content = value;

        }

    }
}
