﻿using MetroFramework.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace ModernUISample
{
    public partial class Form2 : MetroForm
    {
        DataSet ds = null;
        DataTable dt = null;
        string AppPath = string.Empty;
        public Form2()
        {
            InitializeComponent();
            //if (!System.IO.File.Exists(@"c:\Clientdetails.xml"))
            //{
            //    System.IO.File.Create(@"c:\Clientdetails.xml").Close();
            //    XmlDocument doc = new XmlDocument();
            //    doc.LoadXml("<ClientDetails></ClientDetails>");
            //    doc.Save(@"c:\Clientdetails.xml");
            //}
            AppPath = Application.StartupPath + "/Resources";
            ds = new DataSet();
            ds.ReadXml( AppPath + @"\Clientdetails.xml");
            dt = new DataTable("ClientDetails");
            dt.Columns.Add("ClientName");
            if(ds.Tables.Count>0)
            metroGrid1.DataSource = ds.Tables[0];
        }

        private void metroButton1_Click(object sender, EventArgs e)
        {
            DataRow dr = dt.NewRow();
            dr["ClientName"] = metroTextBox1.Text;
            if (ds.Tables.Count == 0)
            {
                dt.Rows.Add(dr);
                ds.Tables.Add(dt);
            }
            else
            {
                dt = ds.Tables[0];
                DataRow dr1 = dt.NewRow();
                dr1["ClientName"] = metroTextBox1.Text;
                dt.Rows.Add(dr1);
                ds.AcceptChanges();
            }
            ds.WriteXml(AppPath + @"\Clientdetails.xml");
            metroGrid1.DataSource = ds.Tables[0];
        }
    }
}
