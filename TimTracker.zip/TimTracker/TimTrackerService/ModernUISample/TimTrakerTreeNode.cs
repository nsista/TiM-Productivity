﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ModernUISample
{
    class TimTrakerTreeNode:TreeNode
    {
        public object Key { get; set; }
        public bool IsDraggable { get; set; }
    }
}
