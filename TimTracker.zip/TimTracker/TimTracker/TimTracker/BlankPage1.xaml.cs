﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using TimTracker.TrackerService;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace TimTracker
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class BlankPage1 : Page
    {
        public BlankPage1()
        {
            this.InitializeComponent();
            StoreData storeData = new StoreData();
            List<GroupInfoList<object>> dataLetter = storeData.GetGroupsByCategory();
            cvs2.Source = dataLetter;
        }
        
    }
    public class ItemSource
{
   public string Title { get; set; }      
   public string Image { get; set; }
   public string Category { get; set; }
   public string Description { get; set; }
}

//Generate one more class in which give the values of these data items as,

public class StoreData
{
   public StoreData()
        {
            ItemSource item;
            item = new ItemSource();
            item.Title = "C#";
            item.Image = "Books/c-sharp.jpg";
            item.Category = "Books";
            item.Description = "Multi Paradigm Programming Language";
            collection.Add(item);
            item = new ItemSource();
            item.Title = "DotNet Framework";
            item.Image = "Books/Dotnet_framework.jpg";
            item.Category = "Books";
            item.Description = "This Book defines Dotnet Framework";
            collection.Add(item);
            item = new ItemSource();
            item.Title = "Dell-Laptop";
            item.Image = "Laptops/Laptop1.jpg";
            item.Category = "Laptop";
            item.Description = "Windows 7 enabled";
            collection.Add(item);
            item = new ItemSource();
            item.Title = "Comopaq Laptop";
            item.Image = "Laptops/Laptop2.jpg";
            item.Category = "Laptop";
            item.Description = "Windows Vista Enabled";
            collection.Add(item);
            item = new ItemSource();
            item.Title = "Nokia 5555";
            item.Image = "Mobile/Mobile1.jpg";
            item.Category = "Mobile";
            item.Description = "Cheapest Mobile Set";
            collection.Add(item);
            item = new ItemSource();
            item.Title = "Nokia 7677";
            item.Image = "Mobile/Mobile2.jpg";
            item.Category = "Mobile";
            item.Description = "Mostly Used Nokia set";
            collection.Add(item);
            item = new ItemSource();
            item.Title = "DotNet";
            item.Image = "Books/net.jpg";
            item.Category = "Books";
            item.Description = "Very Useful for all beggineer";
            collection.Add(item);
            item = new ItemSource();
            item.Title = "Dotnet Technology";
            item.Image = "Books/net_technology.jpg";
            item.Category = "Books";
            item.Description = "Technology related to dotnet";
            collection.Add(item);
            item = new ItemSource();
            item.Title = "Dell";
            item.Image = "Laptops/Laptop3.jpg";
            item.Category = "Laptop";
            item.Description = "Best Operating System";
            collection.Add(item);
            item = new ItemSource();
            item.Title = "Compaq-HP";
            item.Image = "Laptops/Laptop4.jpg";
            item.Category = "Laptop";
            item.Description = "Most Used and very popular";
            collection.Add(item);
            item = new ItemSource();
            item.Title = "WPF";
            item.Image = "Books/wpf.jpg";
            item.Category = "Books";
            item.Description = "WPF Designing";
            collection.Add(item);
        }
   private ItemCollection collection = new ItemCollection();
   internal List<GroupInfoList<object>> Getalldata()
   {
       List<GroupInfoList<object>> groups = new List<GroupInfoList<object>>();
       var query = from item in collection
                   group item by (ItemSource)item into g
                   select new { GroupName = g.Key, Items = g };
       foreach (var g in query)
       {
           GroupInfoList<object> info = new GroupInfoList<object>();
           info.Key = g.GroupName;
           foreach (var item in g.Items)
           {
               info.Add(item);
           }
           groups.Add(info);
       }
       return groups;
   }

   //Write the query for the selection of Data items according to its category as:

   internal List<GroupInfoList<object>> GetGroupsByCategory()
   {
       List<GroupInfoList<object>> groups = new List<GroupInfoList<object>>();
       var query = from item in collection
                   orderby ((ItemSource)item).Category
                   group item by ((ItemSource)item).Category into g
                   select new { GroupName = g.Key, Items = g };
       TrackerServiceClient client = new TrackerServiceClient();
            
            Task<TimActivities> activities =  client.GetActivitiesAsync(null);
            //TimActivities act = await activities;
            if (activities != null)
            {
                var re = activities.Result;
                var val = from a in re.activities
                          join b in re.pInfo on a.ProjectID equals b.ProjectID
                          join c in re.categories on a.CategoryName equals c.CategoryName
                          group a by new { c.CategoryName} into g
                          select new
                          {
                              GroupName = g.Key.CategoryName,
                              Items = g
                          };
                foreach (var g in val)
                {
                    GroupInfoList<object> info = new GroupInfoList<object>();
                    info.Key = g.GroupName;
                    foreach (var item in g.Items)
                    {
                        info.Add(item);
                    }
                    groups.Add(info);
                }
            }
       
       return groups;
   }
} 

//In the preceding code ItemCollection is an Enumerated type class of which the definition is:

class ItemCollection: IEnumerable<Object>
{
     private System.Collections.ObjectModel.ObservableCollection<ItemSource> itemCollection = new System.Collections.ObjectModel.ObservableCollection<ItemSource>();
     public IEnumerator<Object> GetEnumerator()
     {
          return itemCollection.GetEnumerator();
     }
     System.Collections.IEnumerator System.Collections.IEnumerable.GetEnumerator()
     {
          return GetEnumerator();
     }
     public void Add(ItemSource item)
     {
         itemCollection.Add(item);
     }
}

//Now write the query for the selection of all the items as:



//In both of these queries the definition of GroupInfoList<object> is as:


}
