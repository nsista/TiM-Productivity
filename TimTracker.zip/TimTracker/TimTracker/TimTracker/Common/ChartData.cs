﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TimTracker.TrackerService;

namespace TimTracker.Common
{
    class ChartData
    {
        public static int GetQuarter(DateTime date)
        {
            if (date.Month >= 4 && date.Month <= 6)
                return 0;
            else if (date.Month >= 7 && date.Month <= 9)
                return 1;
            else if (date.Month >= 10 && date.Month <= 12)
                return 2;
            else
                return 3;
        }
        public static MainViewModel GetData(DateTime dtSelected)
        {
            TrackerServiceClient client = new TrackerServiceClient();
            MainViewModel main = new MainViewModel();
            Task<TimActivities> activities = client.GetActivitiesAsync(null);
            //TimActivities act = await activities;
            if (activities != null)
            {
                var re = activities.Result;

                var result = from p in re.activities
                             join q in re.pInfo on p.ProjectID equals q.ProjectID
                             where p.ActivityStartTime.Value.Date.ToString("MM/dd/yyyy") == dtSelected.Date.Date.ToString("MM/dd/yyyy")
                             group p by new { q.ProjectName, p.ActivityStartTime } into g
                             select new
                             {
                                 ActivityTime = g.Key.ActivityStartTime,
                                 Name = g.Key.ProjectName,
                                 Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.TimeSpent.Value))
                             };
                var V = from r in result
                        group r by new { r.Name } into g
                        select new
                        {
                            Name = g.Key.Name,
                            Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.Count))
                        };
                foreach (var re1 in V)
                {
                    main.ProjectsInfo.Add(new ProjectInf { Name = re1.Name, Count = re1.Count.TotalSeconds });
                }
            }
            return main;
        }
        public static MainViewModel GetData(DateTime fromDate,DateTime toDate)
        {
            TrackerServiceClient client = new TrackerServiceClient();
            MainViewModel main = new MainViewModel();
            Task<TimActivities> activities = client.GetActivitiesAsync(null);
            //TimActivities act = await activities;
            if (activities != null)
            {
                var re = activities.Result;

                var result = from p in re.activities
                             join q in re.pInfo on p.ProjectID equals q.ProjectID
                             where p.ActivityStartTime.Value.Date >= fromDate && p.ActivityStartTime.Value.Date <= toDate
                             //where p.ActivityStartTime.Value.Date.ToString("MM/dd/yyyy") == dtSelected.Date.Date.ToString("MM/dd/yyyy")
                             group p by new { q.ProjectName, p.ActivityStartTime } into g
                             select new
                             {
                                 ActivityTime = g.Key.ActivityStartTime,
                                 Name = g.Key.ProjectName,
                                 Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.TimeSpent.Value))
                             };
                var V = from r in result
                        group r by new { r.Name } into g
                        select new
                        {
                            Name = g.Key.Name,
                            Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.Count))
                        };
                foreach (var re1 in V)
                {
                    main.ProjectsInfo.Add(new ProjectInf { Name = re1.Name, Count = re1.Count.TotalSeconds });
                }
            }
            return main;
        }
        public static MainViewModel GetWeeklyData()
        {
            TrackerServiceClient client = new TrackerServiceClient();
            MainViewModel main = new MainViewModel();
            Task<TimActivities> activities = client.GetActivitiesAsync(null);
            //TimActivities act = await activities;
            if (activities != null)
            {
                var re = activities.Result;

                var result = from p in re.activities
                             join q in re.pInfo on p.ProjectID equals q.ProjectID
                             where p.ActivityStartTime.Value >= DateTime.Now.AddDays(-7)
                             group p by new { q.ProjectName, p.ActivityStartTime } into g
                             select new
                             {
                                 ActivityTime = g.Key.ActivityStartTime,
                                 Name = g.Key.ProjectName,
                                 Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.TimeSpent.Value))
                             };
                var V = from r in result
                        group r by new { r.Name } into g
                        select new
                        {
                            Name = g.Key.Name,
                            Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.Count))
                        };
                foreach (var re1 in V)
                {
                    main.ProjectsInfo.Add(new ProjectInf { Name = re1.Name, Count = re1.Count.TotalSeconds });
                }
            }
            return main;
        }
        public static MainViewModel GetMonthlyData()
        {
            TrackerServiceClient client = new TrackerServiceClient();
            MainViewModel main = new MainViewModel();
            Task<TimActivities> activities = client.GetActivitiesAsync(null);
            //TimActivities act = await activities;
            if (activities != null)
            {
                var re = activities.Result;

                var result = from p in re.activities
                             join q in re.pInfo on p.ProjectID equals q.ProjectID
                             where p.ActivityStartTime.Value.Month >= DateTime.Now.Date.Month
                             group p by new { q.ProjectName, p.ActivityStartTime } into g
                             select new
                             {
                                 ActivityTime = g.Key.ActivityStartTime,
                                 Name = g.Key.ProjectName,
                                 Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.TimeSpent.Value))
                             };
                var V = from r in result
                        group r by new { r.Name } into g
                        select new
                        {
                            Name = g.Key.Name,
                            Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.Count))
                        };
                foreach (var re1 in V)
                {
                    main.ProjectsInfo.Add(new ProjectInf { Name = re1.Name, Count = re1.Count.TotalSeconds });
                }
            }
            return main;
        }
        public static MainViewModel GetQuarterlyData()
        {
            TrackerServiceClient client = new TrackerServiceClient();
            MainViewModel main = new MainViewModel();
            Task<TimActivities> activities = client.GetActivitiesAsync(null);
            //TimActivities act = await activities;
            if (activities != null)
            {
                var re = activities.Result;

                var result = from p in re.activities
                             join q in re.pInfo on p.ProjectID equals q.ProjectID
                             where (p.ActivityStartTime.Value.Month - 1) / 3 == GetQuarter(DateTime.Now)
                             group p by new { q.ProjectName, p.ActivityStartTime } into g
                             select new
                             {
                                 ActivityTime = g.Key.ActivityStartTime,
                                 Name = g.Key.ProjectName,
                                 Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.TimeSpent.Value))
                             };
                //result.Where("");
                //if (string.IsNullOrEmpty(filter))
                //{
                //    //result = from r in result where r.ActivityTime.Value equals filter select r;
                //}
                var V = from r in result
                        group r by new { r.Name } into g
                        select new
                        {
                            Name = g.Key.Name,
                            Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.Count))
                        };
                foreach (var re1 in V)
                {
                    main.ProjectsInfo.Add(new ProjectInf { Name = re1.Name, Count = re1.Count.TotalSeconds });
                }
            }
            return main;
        }
        public static MainViewModel GetYearlyData()
        {
            TrackerServiceClient client = new TrackerServiceClient();
            MainViewModel main = new MainViewModel();
            Task<TimActivities> activities = client.GetActivitiesAsync(null);
            //TimActivities act = await activities;
            if (activities != null)
            {
                var re = activities.Result;

                var result = from p in re.activities
                             join q in re.pInfo on p.ProjectID equals q.ProjectID
                             where p.ActivityStartTime.Value.Year >= DateTime.Now.Date.Year
                             group p by new { q.ProjectName, p.ActivityStartTime } into g
                             select new
                             {
                                 ActivityTime = g.Key.ActivityStartTime,
                                 Name = g.Key.ProjectName,
                                 Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.TimeSpent.Value))
                             };
                //result.Where("");
                //if (string.IsNullOrEmpty(filter))
                //{
                //    //result = from r in result where r.ActivityTime.Value equals filter select r;
                //}
                var V = from r in result
                        group r by new { r.Name } into g
                        select new
                        {
                            Name = g.Key.Name,
                            Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.Count))
                        };
                foreach (var re1 in V)
                {
                    main.ProjectsInfo.Add(new ProjectInf { Name = re1.Name, Count = re1.Count.TotalSeconds });
                }
            }
            return main;
        }
        public void GetFiscalYearData()
        {

        }
        public static List<GroupInfoList<object>> GetquarterlyData(string ProjectID)
        {
            int quarter = GetQuarter(DateTime.Now);
             TrackerServiceClient client = new TrackerServiceClient();
             List<GroupInfoList<object>> groups = new List<GroupInfoList<object>>();
            Task<TimActivities> activities = client.GetActivitiesAsync(null);
            //TimActivities act = await activities;
            if (activities != null)
            {
                var re = activities.Result;
                var val = from a in re.activities
                          join b in re.pInfo on a.ProjectID equals b.ProjectID
                          join c in re.categories on a.CategoryName equals c.CategoryName
                          where (a.ActivityStartTime.Value.Month - 1) / 3 == quarter && b.ProjectID.ToString() == ProjectID
                          group a by new { c.CategoryName } into g
                          select new
                          {
                              GroupName = g.Key.CategoryName,
                              Items = g
                          };
                foreach (var g in val)
                {
                    GroupInfoList<object> info = new GroupInfoList<object>();
                    info.Key = g.GroupName;
                    foreach (var item in g.Items)
                    {
                        info.Add(item);
                    }
                    groups.Add(info);
                }
            }
            return groups;
            //from a in ActivityLoggers
            //join b in ProjectInfo on a.ProjectID equals b.ProjectID
            //where (a.ActivityStartTime.Value.Month-1)/3 == 3

            //select new{
            //a.ActivityName,
            //a.ActivityStartTime,
            //a.TimeSpent,
            //b.ProjectName
        }
        private MainViewModel GetChart(string filter = null)
        {
            //PieChart pi = new PieChart();
            //EndPointIdentity 
            TrackerServiceClient client = new TrackerServiceClient();
            MainViewModel main = new MainViewModel();
            Task<TimActivities> activities = client.GetActivitiesAsync(null);
            //TimActivities act = await activities;
            if (activities != null)
            {
                var re = activities.Result;

                var result = from p in re.activities
                             join q in re.pInfo on p.ProjectID equals q.ProjectID                             
                             group p by new { q.ProjectName, p.ActivityStartTime } into g
                             select new
                             {
                                 ActivityTime = g.Key.ActivityStartTime,
                                 Name = g.Key.ProjectName,
                                 Count = g.Aggregate(new TimeSpan(0), (p, v) => p.Add(v.TimeSpent.Value))
                             };
                //result.Where("");
                if (string.IsNullOrEmpty(filter))
                {
                    //result = from r in result where r.ActivityTime.Value equals filter select r;
                }
                
                foreach (var re1 in result)
                {
                    main.ProjectsInfo.Add(new ProjectInf { Name = re1.Name, Count = re1.Count.TotalSeconds });
                }
            }
            return main;
        }
    }
}
