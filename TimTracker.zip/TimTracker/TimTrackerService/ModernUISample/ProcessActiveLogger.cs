﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ModernUISample
{
    public class ProcessActiveLogger
    {
        public string ProcessName { get; set; }
        public List<ProcessActivity> ProcActivity { get; set; }
    }
    public class ProcessActivity
    {
        public DateTime ActivityTime { get; set; }
        public int TotalActiveSessionTime { get; set; }
    }
}
